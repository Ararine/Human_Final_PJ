---
name: pretendard-mui-design
description: Use this skill to generate well-branded interfaces and assets for Pretendard MUI — a Material UI v5 design system that swaps Pretendard in for Roboto. Use for production code or throwaway prototypes, mocks, slides, and design artifacts. Contains essential design guidelines, MUI v5 colors, type, fonts, Material Icons, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. The fonts in `fonts/` and the tokens in `colors_and_type.css` are the foundation — include them via `<link rel="stylesheet" href="…/colors_and_type.css">` and use CSS variables (`var(--mui-primary-main)`, `var(--t-h4-size)`, etc.). Material Icons load from the Google Fonts CDN — no asset copying required.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand. The UI kit components in `ui_kits/mui/*.jsx` are cosmetic recreations meant for mockups; in production, use the real `@mui/material` package and theme it with the same tokens.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (audience, target product context, level of fidelity, whether they want variations), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key references inside this skill:
- `README.md` — content fundamentals, visual foundations, iconography
- `colors_and_type.css` — every token (palette, type scale, shadows, spacing, radii)
- `fonts/` — Pretendard 9 weights (.otf)
- `preview/` — design system reference cards
- `ui_kits/mui/` — React component recreations + interactive demo
