// MUI Card / CardMedia / CardContent / CardActions
function MuiCard({ variant = "elevation", elevation = 1, children, sx }) {
  return (
    <div style={{
      background: "#fff",
      borderRadius: 4,
      boxShadow: variant === "outlined" ? "none" : `var(--mui-elev-${elevation})`,
      border: variant === "outlined" ? "1px solid var(--mui-border)" : "none",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      ...sx,
    }}>{children}</div>
  );
}
function MuiCardMedia({ image, height = 160, sx, children }) {
  return (
    <div style={{
      height,
      background: image ? `center/cover no-repeat url(${image})` : "linear-gradient(135deg,#1976d2,#42a5f5)",
      ...sx,
    }}>{children}</div>
  );
}
function MuiCardContent({ children, sx }) {
  return <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 6, ...sx }}>{children}</div>;
}
function MuiCardActions({ children, sx }) {
  return <div style={{ padding: "6px 8px 8px", display: "flex", gap: 4, alignItems: "center", ...sx }}>{children}</div>;
}

window.MuiCard = MuiCard;
window.MuiCardMedia = MuiCardMedia;
window.MuiCardContent = MuiCardContent;
window.MuiCardActions = MuiCardActions;
