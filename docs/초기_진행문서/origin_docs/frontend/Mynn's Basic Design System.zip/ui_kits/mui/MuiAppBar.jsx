// MUI AppBar / Toolbar / IconButton / Avatar
function MuiAppBar({ position = "static", color = "primary", elevation = 4, children, sx }) {
  const bgMap = { primary: "#1976d2", secondary: "#9c27b0", default: "#fff", transparent: "transparent" };
  const fg = color === "default" ? "rgba(0,0,0,0.87)" : "#fff";
  return (
    <header style={{
      background: bgMap[color] || color,
      color: fg,
      boxShadow: `var(--mui-elev-${elevation})`,
      position,
      width: "100%",
      ...sx,
    }}>{children}</header>
  );
}
function MuiToolbar({ children, sx }) {
  return <div style={{ display: "flex", alignItems: "center", minHeight: 64, padding: "0 16px", gap: 8, ...sx }}>{children}</div>;
}
function MuiIconButton({ icon, onClick, color = "inherit", size = "medium", sx, children }) {
  const [hover, setHover] = React.useState(false);
  const d = { small: 30, medium: 40, large: 48 }[size];
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        width: d, height: d, borderRadius: "50%",
        background: hover ? "rgba(0,0,0,0.04)" : "transparent",
        border: "none", color: "inherit", cursor: "pointer",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        transition: "background 150ms",
        ...sx,
      }}>
      {icon ? <span className="material-icons" style={{ fontSize: { small: 18, medium: 24, large: 28 }[size] }}>{icon}</span> : children}
    </button>
  );
}
function MuiAvatar({ children, src, bg = "#9c27b0", size = 40, sx }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: src ? `center/cover no-repeat url(${src})` : bg,
      color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontFamily: "var(--font-sans)", fontSize: size * 0.4, fontWeight: 500,
      ...sx,
    }}>{!src && children}</div>
  );
}

window.MuiAppBar = MuiAppBar;
window.MuiToolbar = MuiToolbar;
window.MuiIconButton = MuiIconButton;
window.MuiAvatar = MuiAvatar;
