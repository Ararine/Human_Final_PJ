// MUI Fab
function MuiFab({ color = "secondary", onClick, children, size = "large", sx }) {
  const bgMap = { primary: "#1976d2", secondary: "#9c27b0", error: "#d32f2f", success: "#2e7d32" };
  const d = { small: 40, medium: 48, large: 56 }[size];
  const [hover, setHover] = React.useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        width: d, height: d, borderRadius: "50%",
        background: bgMap[color] || color, color: "#fff", border: "none",
        cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center",
        boxShadow: hover ? "var(--mui-elev-12)" : "var(--mui-elev-6)",
        transition: "box-shadow 150ms",
        ...sx,
      }}>{children}</button>
  );
}
window.MuiFab = MuiFab;
