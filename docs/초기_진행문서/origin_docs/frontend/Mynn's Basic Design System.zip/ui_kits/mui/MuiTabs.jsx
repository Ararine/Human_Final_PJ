// MUI Tabs / Tab
function MuiTabs({ value, onChange, children, sx }) {
  const tabs = React.Children.toArray(children);
  const refs = React.useRef([]);
  const [bar, setBar] = React.useState({ left: 0, width: 0 });
  React.useEffect(() => {
    const el = refs.current[value];
    if (el) setBar({ left: el.offsetLeft, width: el.offsetWidth });
  }, [value, tabs.length]);
  return (
    <div style={{ position: "relative", borderBottom: "1px solid rgba(0,0,0,0.12)", display: "flex", ...sx }}>
      {tabs.map((t, i) =>
        React.cloneElement(t, {
          key: i,
          selected: i === value,
          onClick: () => onChange(i),
          ref: (el) => (refs.current[i] = el),
        })
      )}
      <div style={{
        position: "absolute", bottom: 0, height: 2,
        background: "#1976d2",
        left: bar.left, width: bar.width,
        transition: "left 200ms cubic-bezier(0.4,0,0.2,1), width 200ms cubic-bezier(0.4,0,0.2,1)",
      }} />
    </div>
  );
}
const MuiTab = React.forwardRef(({ label, selected, onClick }, ref) => (
  <button ref={ref} onClick={onClick} style={{
    background: "transparent", border: "none",
    padding: "12px 16px", minWidth: 90, minHeight: 48,
    font: "500 14px var(--font-sans)", letterSpacing: "0.4px",
    textTransform: "uppercase",
    color: selected ? "#1976d2" : "rgba(0,0,0,0.6)",
    cursor: "pointer",
  }}>{label}</button>
));

window.MuiTabs = MuiTabs;
window.MuiTab = MuiTab;
