// MUI Button — cosmetic recreation
function MuiButton({ variant = "contained", color = "primary", size = "medium", disabled, startIcon, endIcon, children, onClick, fullWidth, sx }) {
  const colorTokens = {
    primary:   { main: "#1976d2", dark: "#1565c0", contrast: "#fff" },
    secondary: { main: "#9c27b0", dark: "#7b1fa2", contrast: "#fff" },
    error:     { main: "#d32f2f", dark: "#c62828", contrast: "#fff" },
    warning:   { main: "#ed6c02", dark: "#e65100", contrast: "#fff" },
    info:      { main: "#0288d1", dark: "#01579b", contrast: "#fff" },
    success:   { main: "#2e7d32", dark: "#1b5e20", contrast: "#fff" },
    inherit:   { main: "rgba(0,0,0,0.87)", dark: "rgba(0,0,0,0.87)", contrast: "#fff" },
  }[color] || { main: "#1976d2", dark: "#1565c0", contrast: "#fff" };

  const [hover, setHover] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);

  const sizePad = { small: "4px 10px", medium: "6px 16px", large: "8px 22px" }[size];
  const sizeFont = { small: 13, medium: 14, large: 15 }[size];

  let base = {
    fontFamily: "var(--font-sans)",
    fontWeight: 500,
    fontSize: sizeFont,
    lineHeight: 1.75,
    letterSpacing: "0.4px",
    textTransform: "uppercase",
    border: variant === "outlined" ? `1px solid ${disabled ? "rgba(0,0,0,0.12)" : colorTokens.main + "80"}` : "none",
    borderRadius: 4,
    padding: variant === "outlined" ? `calc(${sizePad.split(" ")[0]} - 1px) calc(${sizePad.split(" ")[1]} - 1px)` : sizePad,
    cursor: disabled ? "not-allowed" : "pointer",
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    width: fullWidth ? "100%" : "auto",
    justifyContent: "center",
    transition: "background-color 150ms cubic-bezier(0.4,0,0.2,1), box-shadow 150ms cubic-bezier(0.4,0,0.2,1)",
    userSelect: "none",
    ...sx,
  };

  if (variant === "contained") {
    base.background = disabled ? "rgba(0,0,0,0.12)" : (hover ? colorTokens.dark : colorTokens.main);
    base.color = disabled ? "rgba(0,0,0,0.26)" : colorTokens.contrast;
    base.boxShadow = disabled ? "none" : (pressed ? "var(--mui-elev-8)" : (hover ? "var(--mui-elev-4)" : "var(--mui-elev-2)"));
  } else if (variant === "outlined") {
    base.background = hover ? `${colorTokens.main}0A` : "transparent";
    base.color = disabled ? "rgba(0,0,0,0.26)" : colorTokens.main;
  } else {
    base.background = hover ? `${colorTokens.main}0A` : "transparent";
    base.color = disabled ? "rgba(0,0,0,0.26)" : colorTokens.main;
  }

  return (
    <button
      style={base}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onClick={onClick}
    >
      {startIcon}
      {children}
      {endIcon}
    </button>
  );
}

window.MuiButton = MuiButton;
