# MUI v5 UI Kit (Pretendard)

Cosmetic React recreations of core Material UI components, rendered with Pretendard as the type family. Not the real `@mui/material` — these are simplified, mockup-ready versions you can compose into screens.

## Components

| File | What it covers |
|---|---|
| `MuiButton.jsx` | Contained / outlined / text variants, sizes, all 6 colors, disabled, with start/end icons |
| `MuiTextField.jsx` | Outlined / standard / filled, labels, helper text, error state |
| `MuiCard.jsx` | Paper + outlined cards with media, header, actions |
| `MuiAlert.jsx` | All severities, filled / outlined / standard, optional title and close |
| `MuiChip.jsx` | Filled and outlined, with delete, with avatar/icon |
| `MuiAppBar.jsx` | Primary and elevated white variants, leading icon + actions |
| `MuiList.jsx` | List with avatars, secondary text, dividers, selection |
| `MuiDialog.jsx` | Modal with backdrop, title, content, actions |
| `MuiTabs.jsx` | Underlined tabs with indicator |
| `MuiIcon.jsx` | Tiny wrapper around `material-icons` / `material-symbols-outlined` |

## Demo

`index.html` renders an interactive "Inbox" mock — AppBar, Tabs, List of messages, opens a Dialog with a TextField composer. Click a list item to mark read; the "Compose" FAB opens the composer.
