// MUI List / ListItem / ListItemAvatar / ListItemText / Divider
function MuiList({ children, sx }) {
  return <ul style={{ listStyle: "none", padding: 0, margin: 0, background: "#fff", ...sx }}>{children}</ul>;
}
function MuiListItem({ selected, button, onClick, children, secondaryAction, sx }) {
  const [hover, setHover] = React.useState(false);
  return (
    <li
      onClick={button ? onClick : undefined}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: "flex", alignItems: "center", gap: 16,
        padding: "8px 16px", minHeight: 56,
        background: selected ? "rgba(25,118,210,0.08)" : (hover && button ? "rgba(0,0,0,0.04)" : "transparent"),
        cursor: button ? "pointer" : "default",
        position: "relative",
        ...sx,
      }}>
      {children}
      {secondaryAction && <div style={{ marginLeft: "auto" }}>{secondaryAction}</div>}
    </li>
  );
}
function MuiListItemText({ primary, secondary, sx }) {
  return (
    <div style={{ flex: 1, minWidth: 0, ...sx }}>
      <div style={{ font: "400 16px/1.5 var(--font-sans)", letterSpacing: "0.15px", color: "rgba(0,0,0,0.87)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{primary}</div>
      {secondary && <div style={{ font: "400 14px/1.43 var(--font-sans)", letterSpacing: "0.17px", color: "rgba(0,0,0,0.6)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{secondary}</div>}
    </div>
  );
}
function MuiDivider({ sx }) {
  return <hr style={{ border: "none", borderTop: "1px solid rgba(0,0,0,0.12)", margin: 0, ...sx }} />;
}

window.MuiList = MuiList;
window.MuiListItem = MuiListItem;
window.MuiListItemText = MuiListItemText;
window.MuiDivider = MuiDivider;
