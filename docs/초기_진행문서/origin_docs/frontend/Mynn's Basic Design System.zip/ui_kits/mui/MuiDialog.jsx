// MUI Dialog / Modal
function MuiDialog({ open, onClose, title, children, actions, maxWidth = 444 }) {
  if (!open) return null;
  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 1300,
      background: "rgba(0,0,0,0.5)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 16,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "#fff", borderRadius: 4,
        width: "100%", maxWidth,
        boxShadow: "var(--mui-elev-24)",
        display: "flex", flexDirection: "column", maxHeight: "90vh",
      }}>
        {title && <div style={{ font: "500 20px/1.6 var(--font-sans)", letterSpacing: "0.15px", color: "rgba(0,0,0,0.87)", padding: "16px 24px" }}>{title}</div>}
        <div style={{ padding: "0 24px 20px", overflow: "auto", color: "rgba(0,0,0,0.6)", font: "400 16px/1.5 var(--font-sans)", letterSpacing: "0.15px" }}>{children}</div>
        {actions && <div style={{ padding: "8px 16px", display: "flex", justifyContent: "flex-end", gap: 4 }}>{actions}</div>}
      </div>
    </div>
  );
}
window.MuiDialog = MuiDialog;
