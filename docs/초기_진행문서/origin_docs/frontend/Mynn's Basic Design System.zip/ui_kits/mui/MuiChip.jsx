// MUI Chip
function MuiChip({ label, variant = "filled", color = "default", size = "medium", icon, avatar, onDelete, onClick, sx }) {
  const tokens = {
    default:   { bg: "rgba(0,0,0,0.08)", color: "rgba(0,0,0,0.87)", outline: "rgba(0,0,0,0.23)" },
    primary:   { bg: "#1976d2", color: "#fff", outline: "rgba(25,118,210,0.5)" },
    secondary: { bg: "#9c27b0", color: "#fff", outline: "rgba(156,39,176,0.5)" },
    error:     { bg: "#d32f2f", color: "#fff", outline: "rgba(211,47,47,0.5)" },
    warning:   { bg: "#ed6c02", color: "#fff", outline: "rgba(237,108,2,0.5)" },
    info:      { bg: "#0288d1", color: "#fff", outline: "rgba(2,136,209,0.5)" },
    success:   { bg: "#2e7d32", color: "#fff", outline: "rgba(46,125,50,0.5)" },
  }[color];
  const isOut = variant === "outlined";
  const height = size === "small" ? 24 : 32;
  return (
    <div onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      height, padding: "0 12px",
      borderRadius: height / 2,
      background: isOut ? "transparent" : tokens.bg,
      border: isOut ? `1px solid ${color === "default" ? tokens.outline : tokens.outline}` : "none",
      color: isOut ? (color === "default" ? "rgba(0,0,0,0.87)" : tokens.bg) : tokens.color,
      fontFamily: "var(--font-sans)", fontSize: size === "small" ? 12 : 13,
      cursor: onClick ? "pointer" : "default",
      ...sx,
    }}>
      {avatar && <span style={{ marginLeft: -6, display: "inline-flex" }}>{avatar}</span>}
      {icon && <span className="material-icons" style={{ fontSize: size === "small" ? 16 : 18, marginLeft: -4 }}>{icon}</span>}
      <span>{label}</span>
      {onDelete && (
        <span className="material-icons"
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          style={{ fontSize: 18, color: isOut ? "rgba(0,0,0,0.26)" : "rgba(255,255,255,0.7)", cursor: "pointer", marginRight: -4 }}>cancel</span>
      )}
    </div>
  );
}
window.MuiChip = MuiChip;
