// MUI TextField — outlined variant (most common in MUI v5)
function MuiTextField({ label, value, onChange, placeholder, helperText, error, disabled, type = "text", fullWidth, startAdornment, endAdornment, multiline, rows = 3, sx }) {
  const [focused, setFocused] = React.useState(false);
  const filled = !!(value && String(value).length);
  const float = focused || filled;
  const colorMain = error ? "#d32f2f" : (focused ? "#1976d2" : "rgba(0,0,0,0.23)");
  const labelColor = error ? "#d32f2f" : (focused ? "#1976d2" : "rgba(0,0,0,0.6)");
  const borderWidth = (focused || error) ? 2 : 1;
  const Tag = multiline ? "textarea" : "input";

  return (
    <div style={{ display: "inline-flex", flexDirection: "column", width: fullWidth ? "100%" : 240, ...sx }}>
      <div style={{ position: "relative" }}>
        <fieldset style={{
          position: "absolute", inset: 0, top: -5,
          margin: 0, padding: "0 8px",
          border: `${borderWidth}px solid ${disabled ? "rgba(0,0,0,0.12)" : colorMain}`,
          borderRadius: 4,
          pointerEvents: "none",
          transition: "border-color 150ms cubic-bezier(0.4,0,0.2,1)",
        }}>
          <legend style={{
            padding: float ? "0 4px" : 0,
            fontSize: float ? 12 : 0,
            lineHeight: float ? "11px" : 0,
            visibility: "hidden",
            maxWidth: float ? "100%" : 0.01,
            transition: "max-width 80ms cubic-bezier(0.0,0,0.2,1) 50ms",
          }}>{label}</legend>
        </fieldset>
        <label style={{
          position: "absolute",
          left: float ? 9 : (startAdornment ? 36 : 14),
          top: float ? -8 : "50%",
          transform: float ? "scale(0.75)" : "translateY(-50%)",
          transformOrigin: "left top",
          background: float ? "#fff" : "transparent",
          padding: float ? "0 4px" : 0,
          color: disabled ? "rgba(0,0,0,0.38)" : labelColor,
          fontFamily: "var(--font-sans)",
          fontSize: 16,
          letterSpacing: "0.15px",
          pointerEvents: "none",
          transition: "all 150ms cubic-bezier(0.0,0,0.2,1)",
        }}>{label}</label>
        <div style={{ display: "flex", alignItems: "center", padding: multiline ? "12px 14px" : "0 14px", height: multiline ? "auto" : 56 }}>
          {startAdornment && <span style={{ marginRight: 8, color: "rgba(0,0,0,0.54)", display: "inline-flex" }}>{startAdornment}</span>}
          <Tag
            type={type}
            value={value || ""}
            onChange={onChange}
            placeholder={focused ? placeholder : ""}
            disabled={disabled}
            rows={multiline ? rows : undefined}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            style={{
              flex: 1,
              border: "none",
              outline: "none",
              background: "transparent",
              font: "400 16px var(--font-sans)",
              letterSpacing: "0.15px",
              color: disabled ? "rgba(0,0,0,0.38)" : "rgba(0,0,0,0.87)",
              padding: 0,
              resize: multiline ? "vertical" : "none",
              minHeight: multiline ? rows * 24 : "auto",
            }}
          />
          {endAdornment && <span style={{ marginLeft: 8, color: "rgba(0,0,0,0.54)", display: "inline-flex" }}>{endAdornment}</span>}
        </div>
      </div>
      {helperText && (
        <div style={{
          fontFamily: "var(--font-sans)", fontSize: 12, letterSpacing: "0.4px",
          color: error ? "#d32f2f" : "rgba(0,0,0,0.6)",
          padding: "4px 14px 0",
        }}>{helperText}</div>
      )}
    </div>
  );
}

window.MuiTextField = MuiTextField;
