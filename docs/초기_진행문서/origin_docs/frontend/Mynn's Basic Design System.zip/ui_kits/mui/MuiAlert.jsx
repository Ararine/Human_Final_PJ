// MUI Alert
function MuiAlert({ severity = "info", variant = "standard", title, onClose, children, sx }) {
  const tokens = {
    success: { main: "#2e7d32", bg: "#edf7ed", text: "#1e4620", icon: "check_circle" },
    info:    { main: "#0288d1", bg: "#e5f6fd", text: "#014361", icon: "info" },
    warning: { main: "#ed6c02", bg: "#fff4e5", text: "#663c00", icon: "warning" },
    error:   { main: "#d32f2f", bg: "#fdeded", text: "#5f2120", icon: "error" },
  }[severity];

  let bg = tokens.bg, color = tokens.text, iconColor = tokens.main, border = "none";
  if (variant === "filled") { bg = tokens.main; color = "#fff"; iconColor = "#fff"; }
  if (variant === "outlined") { bg = "transparent"; border = `1px solid ${tokens.main}`; color = tokens.main; }

  return (
    <div style={{
      display: "flex", alignItems: "flex-start", gap: 12,
      padding: "6px 16px", borderRadius: 4,
      background: bg, color, border,
      font: "400 14px/1.43 var(--font-sans)", letterSpacing: "0.15px",
      ...sx,
    }}>
      <span className="material-icons" style={{ color: iconColor, fontSize: 22, lineHeight: "1.4" }}>{tokens.icon}</span>
      <div style={{ flex: 1, padding: "7px 0" }}>
        {title && <div style={{ fontWeight: 500, fontSize: 16, marginBottom: 2 }}>{title}</div>}
        {children}
      </div>
      {onClose && (
        <button onClick={onClose} style={{ background: "transparent", border: "none", color: "currentColor", opacity: 0.7, cursor: "pointer", padding: "7px 0" }}>
          <span className="material-icons" style={{ fontSize: 20 }}>close</span>
        </button>
      )}
    </div>
  );
}
window.MuiAlert = MuiAlert;
