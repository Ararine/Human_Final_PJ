# Pretendard MUI Design System

A Material UI v5 design system with **Pretendard** swapped in as the primary typeface in place of Roboto. Every color token, elevation shadow, type scale step, and component shape is faithful to the standard MUI v5 specification — only the typeface differs.

> This is a generic design system, not the brand of a specific product. It can be applied to any product that wants the MUI v5 look with Korean-friendly typography (Pretendard is a Hangul + Latin sans designed to read alongside Apple SD Gothic Neue).

## Sources

| Source | Where |
|---|---|
| Figma — Material UI for Figma (and MUI X) (Community) | mounted as a virtual filesystem; 70 pages, 143 frames |
| Pretendard font family (9 weights, .otf) | originally supplied in `uploads/` — moved to `fonts/` |
| Material UI v5 spec (reference) | https://mui.com/material-ui/ |
| Pretendard project (reference) | https://github.com/orioncactus/pretendard |

## Substitution Notice

The Figma file specifies **Roboto** (and a small amount of Inter Medium for UI affordances) as the type family. We substitute **Pretendard** for both wherever they appear. Pretendard's Latin metrics are very close to Roboto's — the type scale carries over without re-tuning — and its Hangul glyphs make the system production-ready for Korean copy. **If you need pixel-exact Roboto rendering, swap `--font-sans` back to `Roboto, …` in `colors_and_type.css`.**

The Figma kit also uses **Roboto Mono** and **Material Icons**. Roboto Mono remains the mono default; Material Icons usage is documented in the Iconography section.

## Index — what's in this folder

```
README.md                  ← you are here
SKILL.md                   ← Agent Skill manifest (mirror)
colors_and_type.css        ← all CSS variables: palette, type scale, shadows, spacing, radius
fonts/                     ← Pretendard *.otf (9 weights)
assets/                    ← logos, brand marks (none required for vanilla MUI — empty)
preview/                   ← Design System tab cards (Type / Colors / Spacing / Components / Brand)
ui_kits/
  mui/                     ← MUI v5 UI kit — interactive demo app with components
    index.html
    *.jsx                  ← Button, Card, TextField, Alert, AppBar, etc.
```

---

## Content Fundamentals

Material UI is a **library**, not a brand, so its "voice" is the voice of any product that adopts it. The Figma file's own copy gives us a baseline — engineering-clear, neutral, sentence-case prose:

- **Casing.** Sentence case everywhere except labels inside `<Button>` (which the component auto-uppercases via `text-transform`). Headings: "Use typography to present your design and content as clearly and efficiently as possible." Never Title Case marketing headlines.
- **Voice.** Second person, instructive. "Configure", "Use", "Enable", "Choose". The kit reads like documentation — because it is. Imperative for instructions, declarative for descriptions.
- **Tense.** Present tense, active voice. "Spacing enables changing the paddings of instances" — not "you will be able to change".
- **No emoji.** None in the entire kit. Don't add them.
- **No exclamation marks.** Calm, factual, vendor-neutral.
- **Tone.** Direct, slightly formal, never cute. No idioms. Sentences are short to medium; one idea per sentence.
- **Buttons.** Verbs only, upper-cased by MUI. "SUBMIT", "CANCEL", "LEARN MORE", "INSTALL", not "Click here" or "Let's go".
- **Field labels.** Short noun phrases in sentence case. "Email", "Password", "Full name". Helper text below is a full sentence: "Choose a password with at least 8 characters."
- **Errors.** State what happened and what to do. "Email is required.", "Couldn't reach the server. Try again." Never blame the user.
- **Numbers & units.** Numerals (`8`, not "eight"). Always include the unit (`24px`, `8pt`, `1.5×`).

Specific examples taken from the kit:

> "Typography" — slide heading
> "Use typography to present your design and content as clearly and efficiently as possible." — body
> "When you should use Spacing?" — H6 subheading
> "Spacing enables changing the paddings of instances, since Figma does not let you mutate these once the component has been created." — explanation
> "Configurable from Figma Tokens plugin. Spacing is not available as a component API but it is available as props to some layout components like `<Grid>`, `<Stack>`, etc." — caption

---

## Visual Foundations

**Colors.** MUI v5's full default palette. Primary blue `#1976d2`, secondary purple `#9c27b0`, plus the four status colors (error `#d32f2f`, warning `#ed6c02`, info `#0288d1`, success `#2e7d32`). Each color carries `main`, `dark`, `light`, and `contrast` variants. Text is **alpha-on-white** — `rgba(0,0,0,0.87)` primary, `0.6` secondary, `0.38` disabled — not solid greys, so it composites on any tinted surface. Grey scale runs `50 → 900` (`#fafafa → #212121`). A separate **brand purple** `#9747ff` appears as the kit's accent (dashed outlines, 3% wash) — use it only for system/meta UI (annotations, design-tool overlays), not product chrome.

**Type.** Pretendard, weights 100–900. The full MUI v5 scale: `h1` 96/300 down through `h6` 20/500, plus `subtitle1/2`, `body1/2`, `button`, `caption`, `overline`. `h1` and `h2` are Light (300) with negative tracking; `h6` and below sit at Regular/Medium. `button` and `overline` are uppercase via `text-transform`. Letter-spacing matters — every step has a specific value, encoded as `--t-{step}-spacing`.

**Spacing.** 8pt grid. Pads come in multiples of 8: `8 / 16 / 24 / 32 / 40 / 48 / 56 / 64`. Sub-grid `4px` exists for tight clusters (icon-to-label, chip insets). Layouts use `24px` gutters, sections separate with `48–64px`.

**Backgrounds.** Solid white paper (`#ffffff`) on a faint canvas (`rgba(0,0,0,0.04)`). No gradients, no images, no patterns, no grain. Page backgrounds are flat. The only "texture" is the elevation shadow ramp.

**Animation.** Material standard easing — `cubic-bezier(0.4, 0, 0.2, 1)` for both enter and exit, ~200–300ms. Hover/focus fade in over ~150ms. Ripples expand from press point over ~400ms. No bounces, no springs, no overshoot. Snackbars and Dialogs slide+fade; FABs scale on enter; Skeletons pulse (1.5s alternate).

**Hover.** Add a `rgba(0,0,0,0.04)` overlay on text/outlined buttons, and darken filled buttons by ~8% (use the `.dark` shade). IconButtons get a translucent 4% circular ring of the same hue. No shadow change on hover for buttons; raised buttons go from elevation 2 → 4.

**Press / active.** Increase overlay to `0.12` (the `--action-focus` token). Filled buttons drop to elevation 8 momentarily; cards don't depress. Ripple is the primary press feedback.

**Focus.** Visible focus ring: `2px` outline in the component's color, with a 2–3px offset. Inputs use the `outlined` border in the primary color at 2px instead of 1px.

**Disabled.** `rgba(0,0,0,0.38)` text, `rgba(0,0,0,0.12)` border/fill, no shadow, no cursor.

**Borders.** Hairlines. Default border `#e0e0e0` (1px), strong `#bdbdbd`. Dividers are `rgba(0,0,0,0.12)` — alpha so they compose. Outlined buttons and `TextField` (outlined variant) use `rgba(0,0,0,0.23)` until focused.

**Shadows / elevation.** Material's 25-step ramp; this kit uses 0, 1, 2, 3, 4, 6, 8, 12, 16, 24. Each step layers three offset shadows (ambient + penumbra + umbra). Cards rest at 1, raised buttons 2, FAB 6, dialogs 24, menus 8. Inner shadows: none — MUI doesn't use them.

**Transparency & blur.** Backdrops use `rgba(0,0,0,0.5)` solid (no blur). Drawer overlays the same. Snackbars and tooltips are solid charcoal — `rgba(97,97,97,0.92)` — never blurred glass.

**Corner radius.** Default `4px` (cards, alerts, snackbars, filled chips, buttons). Pills `9999px` (FAB, Chip outlined, IconButton). Circle `50%` (Avatar, Radio, Checkbox unchecked ring). Dialogs `4px`; Menus `4px`. Text fields have `4px` (outlined) or square top with bottom border (standard/filled).

**Cards.** White paper, `4px` radius, elevation `1` by default. No border. Padding `16px`. Header → content → actions stack with `16px` gaps. `CardActionArea` adds a ripple to the whole card surface. Variant `outlined` swaps shadow for a `1px` divider-color border.

**Layout rules.** Material breakpoints: `xs 0 / sm 600 / md 900 / lg 1200 / xl 1536`. AppBar fixed at top, 64px tall (56px mobile). Drawer 240–280px. Container max widths follow breakpoints. `Stack` (flex) is the layout primitive; `Grid` for 2-D. Gutters always 24, padding always a multiple of 8.

**Imagery vibe.** Where photography appears in the Figma (and the upstream kit), it's editorial product photography — warm, naturally lit, not over-saturated, no grain. Avatars are full-color portraits. No B&W treatment. Keep photographs feeling like documentation/dashboard content, not marketing brochure.

---

## Iconography

**System.** [Material Icons](https://fonts.google.com/icons) (the Google webfont) — same family the Figma file uses (4 explicit instances + many embedded). We load it from the Google Fonts CDN; you do **not** need to copy SVGs:

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
```

Usage:

```html
<span class="material-icons">favorite</span>
<span class="material-symbols-outlined">settings</span>
```

Sizes: `16`, `20`, `24` (default), `35`. Color via CSS `color`. The font supplies every ligature in the official Material catalog (~2,500 glyphs).

**Variants.** Filled (`material-icons`), Outlined / Rounded / Sharp / Two-tone via `Material Symbols`. The Figma file primarily uses **Filled** for `*Filled` named components (`ChevronRightFilled`, `AddFilled`, `CancelFilled`, `ArrowDropDownFilled`); reach for Filled by default and Outlined for surfaces where heavy ink would compete with content.

**No emoji.** The kit does not use any emoji. Don't introduce them.

**No unicode-as-icon.** No `★`, `▶`, `▲`, etc. as glyphs in UI — always Material Icons.

**Custom SVGs.** Allowed for true brand/product marks (logos, illustrations). Keep stroke weight consistent with Material at the same nominal size (~2px stroke at 24px box for outline icons).

**Sizing rule of thumb.**
- Inline with body text: `20px`
- Buttons: `18px` (start/end adornment)
- IconButtons: `24px` default, `20px` for `size="small"`, `28px` for `size="large"`
- AppBar / list-item leading: `24px`
- AvatarIcon: `24px` inside a `40px` Avatar

---

## Quick reference

| Need | Use |
|---|---|
| A token | `var(--mui-primary-main)`, `var(--mui-text-secondary)`, etc. from `colors_and_type.css` |
| A type step | Class `.t-h4`, `.t-body1`, `.t-caption`, … or the matching `--t-*-size`/`-weight`/`-line`/`-spacing` vars |
| Elevation | `box-shadow: var(--mui-elev-2);` (steps 0,1,2,3,4,6,8,12,16,24) |
| Radius | `border-radius: var(--mui-radius);` (4px) — or `--mui-radius-pill` for FAB/IconButton |
| A component | See `ui_kits/mui/` — pick a `.jsx` file |

---

## What's not (yet) here

- A product brand. This is the vanilla MUI system; add a brand layer on top (logo, accent override, signature illustrations) per product.
- Dark mode tokens. MUI v5 supports it; the Figma is light-only, so this file is too. Adding `--mui-*` overrides under `[data-theme="dark"]` is straightforward when needed.
- Native MUI React components. The UI kit ships cosmetic recreations — not `@mui/material` itself. Use the real library in production; use these recreations for mockups.
